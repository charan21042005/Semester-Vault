import random
import time

from flask import Flask, Response, jsonify, request
from prometheus_client import (CONTENT_TYPE_LATEST, Counter, Gauge, Histogram,
                               generate_latest)

app = Flask(__name__)

# ---------- metric definitions (create ONCE at module level) ----------
REQUESTS = Counter(
    "myapp_http_requests_total", "Total HTTP requests",
    ["method", "endpoint", "status"],
)
LATENCY = Histogram(
    "myapp_http_request_duration_seconds", "Request latency in seconds",
    ["endpoint"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0),
)
IN_PROGRESS = Gauge("myapp_http_requests_in_progress", "Requests currently being processed")
ORDERS = Counter("myapp_orders_created_total", "Orders created (business metric)")


# ---------- automatic instrumentation for every request ----------
@app.before_request
def before():
    request.start_time = time.perf_counter()
    IN_PROGRESS.inc()


@app.after_request
def after(response):
    if request.path != "/metrics":
        # use the ROUTE TEMPLATE (low cardinality), not the raw URL
        endpoint = request.url_rule.rule if request.url_rule else "unmatched"
        elapsed = time.perf_counter() - request.start_time
        LATENCY.labels(endpoint).observe(elapsed)
        REQUESTS.labels(request.method, endpoint, str(response.status_code)).inc()
    IN_PROGRESS.dec()
    return response


# ---------- application routes ----------
@app.route("/")
def home():
    return "<h1>Instrumented Flask app</h1><p>See /metrics</p>"


@app.route("/health")
def health():
    return jsonify(status="ok")


@app.route("/order", methods=["POST", "GET"])
def order():
    time.sleep(random.uniform(0.01, 0.15))      # simulate work
    ORDERS.inc()
    return jsonify(status="created")


@app.route("/slow")
def slow():
    time.sleep(random.uniform(0.3, 1.5))        # simulate a slow endpoint
    return jsonify(status="slow but ok")


@app.route("/flaky")
def flaky():
    if random.random() < 0.3:                   # 30% of requests fail
        return jsonify(error="boom"), 500
    return jsonify(status="ok")


# ---------- the scrape endpoint ----------
@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
