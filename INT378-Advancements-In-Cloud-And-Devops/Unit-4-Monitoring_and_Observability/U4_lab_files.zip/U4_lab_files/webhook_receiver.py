"""Tiny Alertmanager webhook receiver for the lab: prints alerts it receives."""
import json
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        payload = json.loads(self.rfile.read(length) or b"{}")
        print("\n" + "=" * 70, flush=True)
        print(datetime.now().isoformat(timespec="seconds"),
              "| status:", payload.get("status"),
              "| receiver:", payload.get("receiver"), flush=True)
        for alert in payload.get("alerts", []):
            labels = alert.get("labels", {})
            notes = alert.get("annotations", {})
            print(f"  [{alert.get('status', '').upper()}] {labels.get('alertname')} "
                  f"instance={labels.get('instance')} severity={labels.get('severity')}", flush=True)
            print(f"      {notes.get('summary', '')}", flush=True)
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    print("Webhook receiver listening on :5001 ...", flush=True)
    HTTPServer(("0.0.0.0", 5001), Handler).serve_forever()
